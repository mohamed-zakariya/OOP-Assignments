public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        int x = 5;
        System.out.print(x);

        String word = "Welcome To Java";

    }
}